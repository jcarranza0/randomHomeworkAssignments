/** 
 *    author            Jesus Antonio Carranza 
 *    description:       Write plain Java (SE) program computing areas of 
 *                       circles. It will compute and print 10 areas of 
 *                       10 circles. Circles have radius of 0,1,2,...9. Name 
 *                       the program Circle.java
 *    compiles         yes
 *    works            yes
 */
package circles;

/**
 *
 * @author jcarranza3@csustan.edu
 */
public class jcarranza_Circles {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        double area;                                                //establish variable area
        int radius;                                                 //establish variable radius
        for(int i=0; i < 10; i++) {                                 //for statemet to change i 0-9
            radius = i;                                             //let radius = i
            area = Math.PI*radius*radius;                           //formula for area
            System.out.printf("Area of circle with radius %d", i);  //print cirlce number
            System.out.printf(" :\t %.2f \n", area);                //print area
        }
        
        
        
    }
    
}
