
/** 
 *    author            Jesus Antonio Carranza
 *    description:       Use NetBeans to design project called: MyPower 
 *                          It has an index.html The index.html has CS4270 Project Header 
 *                          on top. It will have 1 inputs fields, called limit. It will 
 *                          have a button or link to call the servlet. Servlet name is 
 *                          MyPower. When the servlet is called it will compute powers 
 *                          of 2 from 1 to limit. 
 *    compiles         yes
 *    works            yes
 */
 

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Antonio
 */

public class MyPower extends HttpServlet 
{

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) 
        {
            /* TODO output your page here. You may use following sample code. */
            String limit = request.getParameter("limit");
            float nValue = Float.valueOf(limit.trim());
            
            out.print("<table border= '3' cellpadding='0' cellspacing='0' width='200px' style='text-align:right'>");
            out.print("<tr>");
            out.print("<td><b> n </b></td>");
            out.print("<td><b> 2^n </b></td>");
            out.print("</tr>");
            
            for(int i=1; i<(int)nValue+1; i++){
                int newValue = (int) Math.pow(2,i);
                out.print("<tr>");
                out.print("<td>" + i + "</td>" + "<td>" + newValue + "</td>");
                out.print("</tr>");
            }
            
            out.print("</table>");
               
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() 
    {
        return "Short description";
    }// </editor-fold>

}
